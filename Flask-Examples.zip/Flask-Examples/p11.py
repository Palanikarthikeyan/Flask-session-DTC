import sqlite3

dbh=sqlite3.connect("D:\\emp.db")
sth=dbh.cursor()
sth.execute('create table emp(eid INT,ename TEXT,edept TEXT,ecity TEXT,ecost INT)')

with open("D:\\emp.csv") as fobj:
    for v in fobj:
        v1,v2,v3,v4,v5=v.split(",")
        sth.execute("insert into emp values(?,?,?,?,?)",(v1,v2,v3,v4,v5))

sth.execute("select *from emp")
for v in sth:
    print(v)

'''
# display to monitor
sth.execute("select *from emp")
for v in sth:
    print("{}\t{}\t{}".format(v[0],v[1].title(),v[3].upper()))
    print("-"*25)
'''
wobj=open("D:\\emp.log","w")
sth.execute("select *from emp")
for v in sth:
    wobj.write("{}\t{}\t{}\n".format(v[0],v[1].title(),v[3].upper()))
    wobj.write("-"*25)
    wobj.write("\n")
wobj.close()

# print(open("D:\\emp.log").read())
