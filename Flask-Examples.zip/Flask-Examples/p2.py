from flask import Flask
obj=Flask(__name__)
@obj.route('/')
def f1():
    return "<h1>Welcome to flask app</h1>"
@obj.route('/mypage')
def f2():
    return "<h1>This is mypage</h1>"
# to bind url with a function ->add_url_rule()
# add_url_rule(<URL>,<endPoint>,<function>)
def f3():
    return "<h2>This is default page</h2>"
obj.add_url_rule("/webpage","webpage",f3)

def f4():
    return "<h2>Customer list</h2>"
obj.add_url_rule("/crm","crm",f4)

if __name__ == '__main__':
    obj.run(debug=True)
