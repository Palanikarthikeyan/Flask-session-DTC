from flask import Flask,render_template
obj=Flask(__name__)
@obj.route('/')
def f1():
    return render_template('myhome.html')
@obj.route('/home')
def f2():
    return "<h2><font color=green>Home page</h1></font>"
@obj.route('/contact/<place>')
def f3(place):
    return "<h2>Working City name is:{}</h2>".format(place)
@obj.route('/pincode/<int:pin>')
def f4(pin):
    return "Pin code number is:{}".format(pin)

if __name__ == '__main__':
    obj.run(debug=True)
