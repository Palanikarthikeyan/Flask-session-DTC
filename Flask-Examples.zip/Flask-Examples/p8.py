from flask import Flask,render_template
obj=Flask(__name__)

@obj.route('/mytest/<int:n>')
def f1(n):
    return render_template('mypage.html',count=n)

@obj.route("/myservers/")
def f2():
	servers={'K1':'RHL5','K2':'RHL6','K3':'RHL7'}
	return render_template('mypage.html',d=servers)

if __name__ == '__main__':
    obj.run(debug=True)
