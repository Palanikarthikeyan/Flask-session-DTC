from flask import Flask,url_for,redirect
obj=Flask(__name__)
@obj.route('/')
def f1():
    return "<h1>Welcome to flask app</h1>"

@obj.route("/myblog/")
def f2():
    return "This is sample page"

#url_for(function,keywordArgs)
#                   key=value
@obj.route("/page/")
def f3():
    return redirect(url_for('f2'))

@obj.route("/dept/<dp>")
def f4(dp):
    return "<h2>This is f4 function block dept of {}</h2>".format(dp)

@obj.route("/deptlist/")
def f5():
    return redirect(url_for('f4',dp='DBA'))

@obj.route("/unix")
def f6():
    return "<h2>Selected server name is:unix</h2>"
@obj.route("/Linux")
def f7():
    return "<h2>Current server name is:Linux 7.9</h2>"

@obj.route("/servers/<sname>")
def f8(sname):
    if sname == "unix":
        return redirect(url_for('f6'))
    elif sname == "Linux":
        return redirect(url_for('f7'))
    else:
        return "<h3>Sorry server name:{} is not matched </h3>".format(sname)
if __name__ == '__main__':
    obj.run(debug=True)
