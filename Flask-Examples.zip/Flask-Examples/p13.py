import sqlite3
from flask import Flask,render_template,request
obj=Flask(__name__)
@obj.route("/")
def f1():
    return render_template('myhome.html')

@obj.route("/save",methods = ["POST","GET"])
def f2():
    msg = "msg"
    if request.method == "POST":
        try:
            v1= request.form["n1"]
            v2 = request.form["n2"]
            v3 = request.form["n3"]
            v4 = request.form["n4"]
            v5 = request.form["n5"]
            with sqlite3.connect("D:\\e1.db") as con:
                cur = con.cursor()
                cur.execute("INSERT into emp (eid,ename,dept,place,cost) values (?,?,?,?,?)",(v1,v2,v3,v4,v5))
                con.commit()
                msg = "Your Details have been Successfully Submitted"
        except:
            con.rollback()
            msg = "Sorry! Please fill all the details in the form"
        finally:
            return render_template("result.html",ack = msg)
            con.close()
   
if __name__ == '__main__':
    obj.run(debug=True)
