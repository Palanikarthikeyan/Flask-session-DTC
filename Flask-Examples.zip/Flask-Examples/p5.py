from flask import Flask,request
obj=Flask(__name__)

@obj.route('/mypage',methods=['post'])
def f1():
	login_name=request.form['n1']
	login_pass=request.form['p1']
	return "<h1>Hello {} welcome to flask app<h1>".format(login_name)

if __name__ == '__main__':
    obj.run(debug=True)
