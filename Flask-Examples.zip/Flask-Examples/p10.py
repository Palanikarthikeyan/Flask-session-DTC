from flask import Flask,render_template,jsonify
import json
obj=Flask(__name__)

@obj.route("/mypage")
def f1():
    return '<h1>This is webpage response</h1>'
@obj.route("/mydata")
def f2():
    netinfo={'type':'ethernet','interface':'eth0','IP':['1.2.3.4','1.2.3.6']}
    jd=json.dumps(netinfo)
    return jd
@obj.route("/myapp")
def f3():
    netinfo={'type':'ethernet','interface':'eth0','IP':['1.2.3.4','1.2.3.6']}
    return jsonify(netinfo)
if __name__ == '__main__':
    obj.run(debug=True)
