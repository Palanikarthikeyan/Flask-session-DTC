from flask import Flask,render_template,request
obj=Flask(__name__)

@obj.route('/mypage',methods=['post'])
def f1():
    n=request.form['n1']
    return render_template('mycounters.html',count=int(n))

if __name__ == '__main__':
    obj.run(debug=True)
