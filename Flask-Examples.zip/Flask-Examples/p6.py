from flask import Flask,request,render_template
obj=Flask(__name__)

@obj.route('/mypage',methods=['post'])
def f1():
	login_name=request.form['n1']
	login_pass=request.form['p1']
	return render_template('result.html')

if __name__ == '__main__':
    obj.run(debug=True)
