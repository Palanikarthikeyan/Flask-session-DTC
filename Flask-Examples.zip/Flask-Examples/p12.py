import sqlite3
from flask import Flask,render_template
obj=Flask(__name__)
@obj.route("/")
def f1():
    return "<h1>Welcome to Flask Emp - App</h1>"
@obj.route("/view")
def f2():
    dbh=sqlite3.connect("D:\\emp1.db")
    sth=dbh.cursor()
    sth.execute('drop table if exists emp')
    sth.execute('create table emp(eid INT,ename TEXT,edept TEXT,ecity TEXT,ecost INT)')
    with open("D:\\emp.csv") as fobj:
        for v in fobj:
            v1,v2,v3,v4,v5=v.split(",")
            sth.execute("insert into emp values(?,?,?,?,?)",(v1,v2,v3,v4,v5))
    sth.execute("select *from emp")
    records=sth.fetchall()
    return render_template("display.html",rs=records)
if __name__ == '__main__':
    obj.run(debug=True)
