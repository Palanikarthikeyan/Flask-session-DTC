from flask import Flask,url_for,redirect
obj=Flask(__name__)
@obj.route('/')
def f1():
    return "<h1>Welcome to flask app</h1>"

@obj.route("/myblog/")
def f2():
    return "This is sample page"

#url_for(function,keywordArgs)
#                   key=value
@obj.route("/page/")
def f3():
    return redirect(url_for('f2'))

@obj.route("/dept/<dp>")
def f4(dp):
    return "<h2>This is f4 function block dept of {}</h2>".format(dp)
@obj.route("/deptlist/")
def f5():
    return redirect(url_for('f4',dp='DBA'))

if __name__ == '__main__':
    obj.run(debug=True)
