from flask import Flask,render_template
obj=Flask(__name__)
@obj.route("/myservers/")
def f2():
	servers=['RHL5','RHL6','RHL7']
	return render_template('mypage.html',L=servers)

if __name__ == '__main__':
    obj.run(debug=True)
